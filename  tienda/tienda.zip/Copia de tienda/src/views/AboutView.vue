<template>
  <div class="about">
    <h1>Algo</h1>
  </div>
</template>

<style>

</style>
